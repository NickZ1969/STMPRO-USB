void calculateSecondaryFuel(void);
void calculateSecondarySpark(void);
byte getVE2(void);
byte getAdvance2(void);