#pragma once

extern void testTable2d();